Demo Readme:
This includes,

1. Directory 'InputImages' with sample input images for program. Place it on local machine and update path in program azfaceapi.py. Full input Database can be accessed using URL- http://www.anefian.com/research/face_reco.htm
2. azfaceapi.py - Tested with Python 3.6- Program with Face API calls on input images and storing attributes to Azure Storage Table
3. azfaceattributes.csv - extract file from Azure table stored in Step 2. Its input to Visualization program
4. proj_viz.py - Tested with Python 2.7. It gave some installation issue on my Windows 7 mchine when testing with Python 3.6 so used Python 2.7 and tested. This program create visualization graph showing average age and average smiling face attribute of input batch of faces.