
## This Program reads a set of JPG images to run through Face Detection module using Azure Face API and stores results in Azure Storage Database

## Input Database - Pulled from public image database, http://www.anefian.com/research/face_reco.htm (set of images are only taken for demo)
## Face Detection - Used Azure Face API to pull face attributes
## Output of Face Attributes - Analysis data is stored in Azure Storage Table for Analytics purpose



import string,random,time,azurerm,json
from azure.storage.table import TableService, Entity
import time
import requests
import sys
import glob

# Input image directory
imagerepo = glob.glob('C:/azpx/gt_db/s01/*.jpg')

list_face = imagerepo[:]

# Add subscription key.
subscription_key = '9fa0a02b4fc54e1bb1d0490f1785586b'


# Request headers for locally stored files.
headers = {
     'Content-Type': 'application/octet-stream',
    'Ocp-Apim-Subscription-Key': subscription_key,
}

# Request parameters. 
params = {
    'returnFaceId': 'true',
    'returnFaceAttributes': 'age,gender,smile,glasses,hair,emotion',
}



def az_face_api(img_filename, params, headers ):
#Pass images to Face API
    
    uri_base = 'https://eastus.api.cognitive.microsoft.com'
    
    # Get the data from file
    with open(img_filename, 'rb') as f:
        img_data = f.read()

    try:
        response = requests.post(uri_base + '/face/v1.0/detect', data=img_data, headers=headers, params=params)
        #print (response)
        
        #print ('Response:')
        parsed = response.json()
        
        return parsed
        
    except Exception as e:
        print('Error:')
        print(e)



def img_call(image_list):
#Returns analysis data

    response_list = []
    no_faces_not_detected =0
    
    for image_file in image_list:
        
        # calling sleep to avoid rate limit error
        time.sleep(5) 

        face_id = az_face_api(image_file, params, headers)


        if face_id:
            response_list.append(face_id)
            f_id = face_id[0]['faceId']
            f_age = str(face_id[0]['faceAttributes']['age'])
            f_gender = face_id[0]['faceAttributes']['gender']
            f_glasses = face_id[0]['faceAttributes']['glasses']
            f_smile = str(face_id[0]['faceAttributes']['smile'])
            print ("\n" + "Face ID: " + f_id)
            print ("Age: " + f_age)
            print ("Gender: " + f_gender)
            print ("Glasses: " + f_glasses)
            print ("Smile: " + f_smile)
            
        # Insert data in Azure Storage Table
            table_service = TableService(account_name='azejor77tstorage', account_key='VozCDR8v4W6uvu0Vue1AaAseFlvBeA66bOnL+sHNLFhbG+GH+9NRLdRuRxtn94Njw+EAbcgur4676sP2t8q1wg==')
            time.sleep(1)
            simages = Entity()
            simages.PartitionKey = 'imageinfo'
            simages.RowKey = f_id
            simages.age = f_age
            simages.gender = f_gender
            simages.glasses = f_glasses
            simages.smile = f_smile
            table_service.insert_entity('azfaceattributes', simages)
            print('Created entry in table...')
            

        else:
            response_list.append([{'faceId': None, 'faceRectangle': None}])
            no_faces_not_detected += 1

    print ("\n **** Number of images analyzed: {}".format(len(response_list)), 
           " **** Images with no faces detected : {}".format(no_faces_not_detected))
    return response_list


def main():
	s_a = img_call(list_face)

if __name__ == '__main__':
	main()