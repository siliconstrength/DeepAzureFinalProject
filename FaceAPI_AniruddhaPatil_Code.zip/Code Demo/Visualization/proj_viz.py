
## Data visualization using Pandas on Face attribute data. Find average Age and average smiling face attribute of batch of input faces

import pandas as pd
import seaborn as sns
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt

#Read azfaceattributes.csv file which is export of Face API attributes from Storage table
df = pd.read_csv("azfaceattributes.csv")

#Drop non numeric columns and buid a Dataframe of remaining columns to work with

df1 = df.drop(['PartitionKey', 'RowKey','Timestamp','gender','glasses'], axis=1)
attributes=list(df1.columns)

#Use panda machinery to calculate basic statistics for all numerical columns, min, max, median, average and standard deviation
print "\n***Applying min() : "
print df1.min()
print "\n***Applying max() : "
print df1.max()
print "\n***Applying median() : "
print df1.median()
print "\n***Applying mean() : "
print df1.mean()
print "\n***Applying std() : "
print df1.std()
#Present graphically average age and smiling attributes for attending group
df1.mean().plot(kind='bar')
##scatter_matrix(df1[attributes], figsize=(12,8))
plt.show()