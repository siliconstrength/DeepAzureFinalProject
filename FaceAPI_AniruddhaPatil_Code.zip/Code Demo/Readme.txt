Demo Readme:
This includes,

1. Directory 'InputImages' with sample input images for program. Place it on local machine and update path in program azfaceapi.py. Full input Database can be accessed using URL- http://www.anefian.com/research/face_reco.htm

2. azfaceapi.py - Tested with Python 3.6- Program with Face API calls on input images and storing attributes to Azure Storage Table

3. Directory 'Visualization' has Data visualization elements. azfaceattributes.csv - extract file from Azure table stored in Step 2. Its input to Visualization program proj_viz.py. This program create visualization graph showing average age and average smiling face attribute of input batch of faces. I have placed PNG file of visualization chart generated.